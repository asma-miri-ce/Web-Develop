let cart = JSON.parse(localStorage.getItem('plantCart')) || [];

        function updateCartCount() {
            const count = cart.reduce((sum, item) => sum + item.quantity, 0);
            document.getElementById('cartCount').textContent = count || 0;
        }
       /* function showmsg (text){
                const msg= document.createElement('div');
                msg.className='cart-message';
                msg.textContent=text;
                document.body.appendChild(msg);

                setTimeout(() => {
                    msg.remove();
                }, 2000);
            }
*/
        function addProduct(title, price, image) {
            const existing = cart.find(item => item.title === title);
            if (existing) {
                existing.quantity += 1;
            } else {
                cart.push({ title, price, image, quantity: 1 });
            }
            
            localStorage.setItem('plantCart', JSON.stringify(cart));
            updateCartCount();
           /*showmsg(title + ' added to shopping cart');*/

            alert(title + ' added to shopping cart ');
            
            
        }

            document.querySelector('.Add_to_cart').onclick = function () {
                const title = document.querySelector('.plant_title').textContent;
                const price = parseInt(document.querySelector('.plant_price').textContent.replace('$',''));
                const image = document.querySelector('.plant_image').src;

                addProduct(title, price, image);
            };


        document.querySelectorAll('.add').forEach(btn => {
            btn.onclick = function (e) {
                e.stopPropagation(); 
                const card = this.closest('.card');
                const title = card.querySelector('.title').textContent;
                const price = parseInt(card.querySelector('.price').textContent.replace('$', ''));
                const image = card.querySelector('.main img').src;
                addProduct(title, price, image);
            };
        });

        document.querySelectorAll('.card').forEach(card => {
            card.onclick = function (e) {
                if (e.target.classList.contains('add')) return;
                const title = this.querySelector('.title').textContent;
                const price = this.querySelector('.price').textContent;
                const info = this.querySelector('.info').textContent;
                const img = this.querySelector('.main img').src;
                document.querySelector('.plant_title').textContent = title;
                document.querySelector('.plant_price').textContent = price;
                document.querySelector('.plant_info').textContent = info;
                document.querySelector('.plant_image').src = img;
            };
        });

        document.getElementById('cartBtn').onclick = () => {
            window.location.href = 'cart.html';
        };

        updateCartCount();
