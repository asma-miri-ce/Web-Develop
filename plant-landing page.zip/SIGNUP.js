document.getElementById('signupBtn').onclick = (e) => {
    e.preventDefault(); 

    const name = document.querySelector('input[name="Username"]').value.trim();
    const email = document.querySelector('input[name="Email"]').value.trim();
    const password = document.querySelector('input[name="Password"]').value;

    const msg = document.getElementById('errorMsg') || document.createElement('p');
    msg.id = 'errorMsg';
    msg.style.color = 'red';
    msg.style.marginTop = '15px';
    if(!document.getElementById('errorMsg')) {
        document.querySelector('.input-wrapper').appendChild(msg);
    }

    if(name === '') {
        msg.textContent = "Name cannot be empty.";
        return;
    }
     
    const nameregex=/^[^0-9]/
    if(!nameregex.test(name)) {
        msg.textContent = "name cant start with number";
        return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if(!emailRegex.test(email)) {
        msg.textContent = "Enter a valid email address.";
        return;
    }

    const minLength = 7;
    const hasUpper = /[A-Z]/.test(password);
    const hasNumber = /[0-9]/.test(password);
    const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(password);

    if(password.length < minLength) {
        msg.textContent = "Password must be at least 7 characters long.";
        return;
    }
    if(!hasUpper) {
        msg.textContent = "Password must include at least one uppercase letter.";
        return;
    }
    if(!hasNumber) {
        msg.textContent = "Password must include at least one number.";
        return;
    }
    if(!hasSpecial) {
        msg.textContent = "Password must include at least one special character (!@#$...).";
        return;
    }

    msg.style.color = 'green';
    msg.textContent = "Sign Up successful!";
    setTimeout(() => {
        window.location.href = 'index4.html';
    }, 1000);
};