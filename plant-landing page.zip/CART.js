let cart = JSON.parse(localStorage.getItem('plantCart')) || [];

    function updateCart() {
        const container = document.getElementById('cartItems');
        const totalEl = document.getElementById('totalPrice');
        container.innerHTML = '';

        if (cart.length === 0) {
            container.innerHTML = '<p class="empty">cart is empty!</p>';
            totalEl.textContent = '$0';
            return;
        }

        let total = 0;
        cart.forEach((item, index) => {
            total += item.price * item.quantity;
            

            const div = document.createElement('div');
            div.className = 'cart-item';
            div.innerHTML = `
                <img src="${item.image}" alt="${item.title}">
                <div class="item-info">
                    <h3>${item.title}</h3>
                    <div class="quantity">
                        <button class="minus" onclick="changeQty(${index}, -1)">-</button>
                        <span>${item.quantity}</span>
                        <button class="plus" onclick="changeQty(${index}, 1)">+</button>
                    </div>
                    <p>$${item.price} × ${item.quantity} = $${item.price * item.quantity}</p>
                </div>
                <div class="item-actions">
                    <button class="remove-btn" onclick="removeItem(${index})">Delete</button>
                    <button class="checkout-btn" onclick="checkoutItem(${index})">Complete Shop</button>
                </div>
            `;
            container.appendChild(div);
        });
    
        totalEl.textContent = '$' + total;
    }

    function changeQty(index, change) {
        if (cart[index].quantity + change >= 1) {
            cart[index].quantity += change;
            localStorage.setItem('plantCart', JSON.stringify(cart));
            updateCart();
        }
    }

    function removeItem(index) {
        cart.splice(index, 1);
        localStorage.setItem('plantCart', JSON.stringify(cart));
        updateCart();
    }

    function checkoutItem(index) {
        const item = cart[index];
        alert(`Thanks for buying ${item.title}! Total: $${item.price * item.quantity}`);
        cart.splice(index, 1); // حذف محصول بعد از خرید
        localStorage.setItem('plantCart', JSON.stringify(cart));
        updateCart();
    }

    document.getElementById('checkout').onclick = () => {
        if (cart.length === 0) return alert('EMPTY');
        alert('Thanks for shopping all items!');
        cart = [];
        localStorage.setItem('plantCart', JSON.stringify(cart));
        updateCart();
    };

    updateCart();